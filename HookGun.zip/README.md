# Overview
A HookGun for LethalCompany, maybe a LethalHook?
THE COMPANY APPROVES!!!

# Installation Instructions:
Place the .dll file inside \BepInEx\plugins

# How To Get Item:
Purchase from the store.

# Screenshots
![](https://i.imgur.com/TIhtI9F.png)
![](https://i.imgur.com/aLx6Rst.png)
![](https://i.imgur.com/nLsEYW4.png)
![](https://i.imgur.com/qkfCjQ0.png)

# KNOW ISSUES!!
- Using the hook to cross pits will send you straight to hell.
- Some areas inside factory will stuck you for a few seconds.

# Changelog
- V 1.0.0 Posted

# Donations
- Please remember that this mod is FREE and will always be. I made it hoping that you would enjoy and have fun!

- But if you are feeling generous to pay me a coffee, click >  <a href='https://ko-fi.com/M4M1LVGAO' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://storage.ko-fi.com/cdn/kofi1.png?v=3' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>

# Contact
- If you found any bugs or just want to get in touch, you can find me here: lianeko2302@gmail.com

# Credits
- HOOKGUN MODEL CREDITS:
- "Hook Gun" (https://skfb.ly/oMRUY) by CristianMFQ is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).

- UNITY TEMPLATE PROJECT:
- https://github.com/EvaisaDev/LethalCompanyUnityTemplate/tree/main

- SHOTGUN MOD:
- https://thunderstore.io/c/lethal-company/p/Radsi2/Shotgun/